<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Our History | B.D.S Public School</title>
  <link rel="icon" href="assets/Photo/logo.png" type="image/x-icon">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      background-color: #f4f9ff;
      color: #333;
    }

    .banner {
      width: 100%;
      height: 400px;
      object-fit: cover;
      display: block;
    }

    .container {
      max-width: 1200px;
      margin: 40px auto;
      padding: 0 20px;
    }

    .title {
      text-align: center;
      font-size: 34px;
      color: #004080;
      margin-bottom: 10px;
    }

    .subtitle {
      text-align: center;
      font-size: 18px;
      color: #777;
      margin-bottom: 40px;
    }

    .history-text {
      line-height: 1.8;
      font-size: 17px;
      text-align: justify;
    }

    @media (max-width: 768px) {
      .banner {
        height: 250px;
      }
    }
  </style>
</head>
<body>
<?php include('include/navbar.php');?>
  <!-- Full-width banner image -->
  <img src="https://raghavfoundation.org.in/wp-content/uploads/2023/05/school-image.jpg" alt="B.D.S Public School" class="banner">

  <!-- Main Content -->
  <div class="container">
    <h1 class="title">Our Journey Through Time</h1>
    <p class="subtitle">A Legacy of Learning, Leadership, and Excellence Since 2005</p>

    <div class="history-text">
      <p>
        B.D.S Public School was established in 2005 with a bold vision — to offer quality education that empowers students with not just knowledge, but values and leadership. What began as a humble institution with a handful of students has today grown into one of the most respected schools in the region.
      </p>
      <p>
        Our founders believed that education must go beyond textbooks. With this philosophy, they laid the foundation of a school that encourages curiosity, creativity, and compassion. The early years were marked by challenges, but our unwavering commitment to students and learning brought us community support and trust.
      </p>
      <p>
        In the late 2005s, the school expanded its campus and introduced smart classrooms and science laboratories. By the early 2000s, B.D.S Public School became known for producing top academic results and all-round achievers.
      </p>
      <p>
        In 2005, we launched our senior secondary section, offering streams in Science and Commerce. The same year saw the introduction of extracurricular programs in arts, music, debate, and technology — helping students develop critical thinking and real-world skills.
      </p>
      <p>
        Over the last three decades, B.D.S Public School has built a reputation for its academic integrity, discipline, and strong value-based teaching. Our alumni have gone on to excel in fields like medicine, engineering, civil services, entrepreneurship, and education.
      </p>
      <p>
        Today, with modern facilities, a highly experienced faculty, and a progressive mindset, B.D.S Public School continues to lead the way in transformative education. We proudly host cultural festivals, science exhibitions, sports tournaments, and interschool collaborations to enrich student life.
      </p>
      <p>
        As we look to the future, our mission remains the same — to create a nurturing environment where children become confident, responsible citizens of the world.
      </p>
      <p>
        We thank every teacher, student, parent, and staff member who has been a part of our journey. Your faith, effort, and spirit have made B.D.S Public School what it is today — not just a school, but a family and a legacy.
      </p>
      <p>
        With gratitude and pride, we continue the journey — one student, one dream, and one future at a time.
      </p>
    </div>
  </div>
  <script>
// Right Click Disable
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Text Selection Disable
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
});

// Copy, Cut, Paste Disable
document.addEventListener('copy', function(e) {
    e.preventDefault();
});
document.addEventListener('cut', function(e) {
    e.preventDefault();
});
document.addEventListener('paste', function(e) {
    e.preventDefault();
});

// Keyboard Shortcuts Disable (Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I etc.)
document.addEventListener('keydown', function(e) {
    if (
        (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's' || e.key === 'a')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'j')) ||
        (e.key === 'F12')
    ) {
        e.preventDefault();
    }
});
</script>

<?php include('include/footer.php');?>
</body>
</html>
