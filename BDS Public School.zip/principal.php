<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Principal's Message | B.D.S Public School</title>
  <link rel="icon" href="assets/Photo/logo.png" type="image/x-icon">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      background-color: #f7fafd;
      color: #333;
    }

    /* Full-width banner image */
    .banner-image {
        margin-top: 0px;
      width: 100%;
      height: 600px;
      object-fit: cover;
      display: block;
    }

    .container {
      max-width: 1000px;
      margin: 30px auto;
      padding: 0 20px;
    }

    .section-title {
      text-align: center;
      font-size: 32px;
      margin-bottom: 20px;
      color: #004080;
    }

    .message-text {
      line-height: 1.8;
      font-size: 17px;
      text-align: justify;
    }

    .principal-name {
      margin-top: 30px;
      font-weight: bold;
      color: #004080;
      font-size: 18px;
      text-align: right;
    }

    @media (max-width: 768px) {
      .banner-image {
        height: 250px;
      }
    }
  </style>
</head>
<body>
<?php  include('include/navbar.php');?>
  <!-- Full-width image -->
  <img src="assets/Photo/2.jpeg" alt="Principal Photo" class="banner-image" />

  <div class="container">
    <h2 class="section-title">Principal's Message</h2>
    <div class="message-text">
      <p>
        Welcome to B.D.S Public School – a place where excellence meets purpose. As the Principal of this vibrant institution, I take immense pride in the holistic growth of our students. Education is not just the accumulation of knowledge but the empowerment of the mind and soul.
      </p>
      <p>
        At B.D.S Public School, we believe that every child has a unique spark within. Our aim is to nurture that spark into a blazing light of confidence, creativity, and character. We create an environment where students feel inspired to question, explore, and dream beyond boundaries.
      </p>
      <p>
        In the rapidly changing global landscape, we prepare our students not just to succeed academically, but to lead with integrity, empathy, and resilience. We emphasize values, discipline, and compassion alongside excellence in science, arts, and sports.
      </p>
      <p>
        Our teaching faculty is dedicated, our infrastructure is modern, and our vision is progressive. We value open communication with parents and believe in a strong school-home partnership. Together, we shape future citizens who are responsible, capable, and morally grounded.
      </p>
      <p>
        To our students, I say – dream big, work hard, be kind, and stay curious. You are the changemakers of tomorrow. Each step you take here is a step toward a brighter, bolder future. Don’t be afraid to fail, but always be ready to learn and rise.
      </p>
      <p>
        To the parents, thank you for trusting us with your children’s future. To the teachers, thank you for being the torchbearers of knowledge. And to the students – believe in yourself, because we believe in you.
      </p>
      <p class="principal-name">– <br>Principal, B.D.S Public School</p>
    </div>
  </div>
  <script>
// Right Click Disable
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Text Selection Disable
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
});

// Copy, Cut, Paste Disable
document.addEventListener('copy', function(e) {
    e.preventDefault();
});
document.addEventListener('cut', function(e) {
    e.preventDefault();
});
document.addEventListener('paste', function(e) {
    e.preventDefault();
});

// Keyboard Shortcuts Disable (Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I etc.)
document.addEventListener('keydown', function(e) {
    if (
        (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's' || e.key === 'a')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'j')) ||
        (e.key === 'F12')
    ) {
        e.preventDefault();
    }
});
</script>

<?php  include('include/footer.php');?>
</body>
</html>
