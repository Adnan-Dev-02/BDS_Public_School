<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login | B.D.S Public School</title>
  <link rel="stylesheet" href="/assets/css/login.css">
  <link rel="icon" href="assets/Photo/logo.png" type="image/x-icon">
 </head>
<body>
<?php  include('include/navbar.php');?>
  <!-- Login Form -->
  <div class="login-container">
    <h2>Login</h2>
    <form action="#" method="POST">
      <div class="form-group">
        <label for="username">Email or Username</label>
        <input type="text" id="username" name="username" required placeholder="Enter your username" />
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required placeholder="Enter your password" />
      </div>
      <button type="submit" class="btn" name="submit">Login</button>
    </form>
    <div class="login-footer">
      <p><a href="#" style="text-align:left;">Don't have an account</a><br><a href="#">Forgot Password</a></p>
    </div>
  </div>
  <script>
// Right Click Disable
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Text Selection Disable
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
});

// Copy, Cut, Paste Disable
document.addEventListener('copy', function(e) {
    e.preventDefault();
});
document.addEventListener('cut', function(e) {
    e.preventDefault();
});
document.addEventListener('paste', function(e) {
    e.preventDefault();
});

// Keyboard Shortcuts Disable (Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I etc.)
document.addEventListener('keydown', function(e) {
    if (
        (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's' || e.key === 'a')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'j')) ||
        (e.key === 'F12')
    ) {
        e.preventDefault();
    }
});
</script>

    <?php include('include/footer.php');?>
</body>
</html>
