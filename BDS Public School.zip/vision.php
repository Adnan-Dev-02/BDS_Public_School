<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Vision & Mission | B.D.S Public School</title>
  <link rel="icon" href="assets/Photo/logo.png" type="image/x-icon">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f9ff;
      color: #333;
    }

    .banner {
        width:100%;
        height: 700px;
        align-items: center;
      background-image: url('https://www.fibovil.com/Static/img/visionn.png');
      background-size: 100% 100%;
      background-repeat: no-repeat;
      display: block;
     
    }

    .container {
      max-width: 1200px;
      margin: 40px auto;
      padding: 0 20px;
    }

    h2 {
      text-align: center;
      font-size: 34px;
      color: #004080;
      margin-bottom: 10px;
    }

    .subtitle {
      text-align: center;
      font-size: 18px;
      color: #777;
      margin-bottom: 40px;
    }

    .section {
      background-color: #ffffff;
      padding: 30px;
      margin-bottom: 30px;
      border-left: 6px solid #004080;
      box-shadow: 0 0 10px rgba(0,0,0,0.05);
      border-radius: 8px;
    }

    .section h2 {
      color: #004080;
      font-size: 24px;
      margin-bottom: 15px;
    }

    .section p {
      font-size: 17px;
      line-height: 1.8;
      text-align: justify;
    }

    @media (max-width: 768px) {
      .banner {
        height: 300px;
      }
      .container {
      max-width: 1300px;
      margin: 10px auto;
      padding: 0 20px;
    }

    .section h2 {
      color: #004080;
      font-size: 20px;
      margin-bottom: 15px;
    }

    .section p {
      font-size: 17px;
      line-height: 1.8;
      text-align: left;
    }
    }
  </style>
</head>
<body>
<?php  include('include/navbar.php');?>
  <!-- Full-width image -->
  <img src="" alt="" />
<div class="banner" ></div>
  <!-- Content Container -->
  <div class="container">
    <h2>Our Vision & Mission</h2>
    <p class="subtitle">Inspiring young minds to shape a better future</p>

    <!-- Vision Section -->
    <div class="section">
      <h2>🌟 Our Vision</h2>
      <p>
        At B.D.S Public School, our vision is to nurture a community of compassionate, innovative, and resilient individuals who are prepared to make meaningful contributions to the world. We strive to create an inclusive learning environment where students can discover their true potential, excel in their pursuits, and evolve into responsible global citizens. Through a blend of traditional values and modern teaching practices, we aim to inspire lifelong learning and leadership.
      </p>
    </div>

    <!-- Mission Section -->
    <div class="section">
      <h2>🎯 Our Mission</h2>
      <p>
        Our mission is to provide quality education that empowers students intellectually, morally, and socially. We are committed to:
        <br><br>
        • Delivering student-centered learning experiences<br>
        • Encouraging critical thinking, creativity, and collaboration<br>
        • Fostering respect, empathy, and cultural understanding<br>
        • Equipping students with skills for academic and personal success<br>
        • Promoting discipline, responsibility, and ethical leadership<br><br>
        With a passionate team of educators and a robust curriculum, we work every day to prepare our students for challenges ahead — not just to succeed, but to lead with purpose.
      </p>
    </div>
  </div>
  <script>
// Right Click Disable
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Text Selection Disable
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
});

// Copy, Cut, Paste Disable
document.addEventListener('copy', function(e) {
    e.preventDefault();
});
document.addEventListener('cut', function(e) {
    e.preventDefault();
});
document.addEventListener('paste', function(e) {
    e.preventDefault();
});

// Keyboard Shortcuts Disable (Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I etc.)
document.addEventListener('keydown', function(e) {
    if (
        (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's' || e.key === 'a')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'j')) ||
        (e.key === 'F12')
    ) {
        e.preventDefault();
    }
});
</script>

<?php  include('include/footer.php');?>
</body>
</html>
