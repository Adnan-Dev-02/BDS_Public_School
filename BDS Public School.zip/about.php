<?php include('include/navbar.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>About Us | B.D.S Public School</title>
  <link rel="stylesheet" href="/assets/css/about.css">
  <link rel="icon" href="assets/Photo/logo.png" type="image/x-icon">
 
</head>
<body>
  <!-- About Section -->
  <section>
    <h2>About B.D.S Public School</h2>

    <div class="about-grid">
      <div class="card">
        <h3>Our Mission</h3>
        <p>To nurture young minds with knowledge, values, discipline, and leadership for a better tomorrow.</p>
      </div>
      <div class="card">
        <h3>Our Vision</h3>
        <p>To become a beacon of academic excellence and character-building in India’s school education ecosystem.</p>
      </div>
      <div class="card">
        <h3>Our Journey</h3>
        <p>Since 2005, we've empowered 15,000+ students with holistic education, preparing them for global challenges.</p>
      </div>
    </div>

    <!-- Philosophy -->
    <div class="section-block">
      <h3>Our Philosophy</h3>
      <p>
        We believe that education must go beyond textbooks. At B.D.S Public School, we foster curiosity, creativity, collaboration, and compassion. Our students are trained not just to pass exams but to make a difference.
      </p>
    </div>

    <!-- Infrastructure -->
    <div class="section-block">
      <h3>Campus & Infrastructure</h3>
      <p>
        Spread across 5 acres in Civil Lines, our campus features:
        <ul>
          <li>✔️ Smart classrooms with digital boards</li>
          <li>🔬 Fully-equipped science & computer labs</li>
          <li>📚 Digital library & language lab</li>
          <li>🏏 Playground, basketball court & yoga space</li>
          <li>🎭 Auditorium, music & art rooms</li>
        </ul>
      </p>
    </div>

    <!-- Faculty -->
    <div class="section-block">
      <h3>Faculty & Staff</h3>
      <p>
        Our 80+ faculty members are handpicked for their qualifications, experience, and commitment. Regular teacher training ensures the latest pedagogical methods are in use. Many teachers are certified by CBSE and the British Council.
      </p>
    </div>

    <!-- Student Life -->
    <div class="section-block">
      <h3>Student Life & Clubs</h3>
      <p>
        From science club to music band, and debate society to coding classes — students experience vibrant campus life. Annual events like Founders Day, Science Expo, and Sports Week give students real-world confidence.
      </p>
    </div>

    <!-- Awards -->
    <div class="section-block">
      <h3>Awards & Recognitions</h3>
      <ul>
        <li>🏆 CBSE Academic Excellence Award – 2023</li>
        <li>🎖️ Best Infrastructure (UP) by Education Today</li>
        <li>🥇 3x National Science Olympiad Gold</li>
        <li>🎨 Winners – National Inter-school Art Fest</li>
      </ul>
    </div>

    <!-- Parent Involvement -->
    <div class="section-block">
      <h3>Parent Engagement</h3>
      <p>
        We host regular PTMs, parenting workshops, and offer a parent portal for real-time performance updates. We consider parents our partners in every child's success.
      </p>
    </div>

    <!-- Academic Stats -->
    <div class="section-block">
      <h3>Academic Performance</h3>
      <p>
        • 100% Pass Rate in Class 10 & 12 (Last 5 Years) <br />
        • Average Class 12 Score (2024): 88.6% <br />
        • Topper (2024): Ayush Sharma – 97.2%
      </p>
    </div>

    <!-- Principal Message -->
    <div class="section-block">
      <h3>Message from the Principal</h3>
      <p>
        “At B.D.S Public School, we are committed to building a future that is morally strong, academically bright, and emotionally balanced. We welcome each learner to grow in an atmosphere of encouragement and curiosity.”<br/>
        <strong>– Dr. Asha Mehta, Principal</strong>
      </p>
    </div>

    <!-- Highlight Strip -->
    <div class="highlight">
      🎓 15,000+ Alumni | 🏫 35 Years of Legacy | 🌍 Global Outlook | 🧠 Focused on Future-Ready Skills
    </div>
  </section>
<script>
// Right Click Disable
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Text Selection Disable
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
});

// Copy, Cut, Paste Disable
document.addEventListener('copy', function(e) {
    e.preventDefault();
});
document.addEventListener('cut', function(e) {
    e.preventDefault();
});
document.addEventListener('paste', function(e) {
    e.preventDefault();
});

// Keyboard Shortcuts Disable (Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I etc.)
document.addEventListener('keydown', function(e) {
    if (
        (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's' || e.key === 'a')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'j')) ||
        (e.key === 'F12')
    ) {
        e.preventDefault();
    }
});
</script>

  <?php include('include/footer.php');?>
</body>
</html>
