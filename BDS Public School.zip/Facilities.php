<?php include('include/navbar.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Facilities | M.R Public School</title>
 <link rel="stylesheet" href="./assets/css/Facilities.css">
 <style>
     * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', sans-serif;
    background: #f4f4f4;
    color: #333;
}

section {
    max-width: 1100px;
    margin: 50px auto;
    padding: 0 20px;
}

h2 {
    text-align: center;
    color: #004080;
    margin-bottom: 25px;
    font-size: 2rem;
}

.facility-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 25px;
}

.facility-card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    display: flex;
    flex-direction: column;
}

.facility-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
}

.facility-card img {
    width: 100%;
    height: 180px;
    object-fit: cover;
}

.facility-content {
    padding: 20px;
}

.facility-content h3 {
    font-size: 1.2rem;
    color: #004080;
    margin-bottom: 10px;
}

.facility-content p {
    line-height: 1.6;
    font-size: 0.95rem;
}
 </style>
</head>
<body>
  <!-- Facilities Section -->
  <section>
    <h2>Our Facilities</h2>
    <div class="facility-grid">

      <div class="facility-card">
        <img src="https://www.digitalchalk.in/wp-content/uploads/2023/09/Smart-School.jpeg" alt="Smart Class">
        <div class="facility-content">
          <h3>Smart Classes</h3>
          <p>Digital boards and multimedia tools make learning interactive and engaging in every classroom.</p>
        </div>
      </div>

      <div class="facility-card">
        <img src="https://png.pngtree.com/background/20250216/original/pngtree-young-man-reading-in-a-library-with-bookshelves-the-background-picture-image_15754215.jpg" alt="Library">
        <div class="facility-content">
          <h3>Library & Labs</h3>
          <p>Our digital library and fully equipped science labs foster inquiry and research among students.</p>
        </div>
      </div>

      <div class="facility-card">
        <img src="https://library.playlsi.com/transform/5dd441d4-587b-4fed-80a8-357457c477f4/KY-Smart-Start-Daycare-176?io=transform:extend,width:1920,height:1080,background:f9f9f9" alt="Playground">
        <div class="facility-content">
          <h3>Sports & Playground</h3>
          <p>Large open fields, courts, and indoor sports areas support physical fitness and team building.</p>
        </div>
      </div>

      <div class="facility-card">
        <img src="https://resources.finalsite.net/images/f_auto,q_auto,t_image_size_2/v1740756988/brynmawrschoolorg/bxpe5riy4qf6fhx4yeoe/24_Arts_010.jpg" alt="Art & Music">
        <div class="facility-content">
          <h3>Art, Music & Yoga</h3>
          <p>Dedicated studios for creative arts, music classes, and weekly yoga sessions ensure holistic growth.</p>
        </div>
      </div>

      <div class="facility-card">
        <img src="https://5.imimg.com/data5/DJ/PV/GLADMIN-64970456/computer-lab-class.png" alt="Computer Lab">
        <div class="facility-content">
          <h3>Computer Lab & Robotics</h3>
          <p>Our tech lab introduces students to coding, robotics, and AI from early grades.</p>
        </div>
      </div>

      <div class="facility-card">
        <img src="https://images.mid-day.com/images/images/2022/jan/School-bus-operators-open-a_d.jpg" alt="Transport">
        <div class="facility-content">
          <h3>Transport & Safety</h3>
          <p>Safe and GPS-enabled buses with CCTV and female attendants ensure secure travel.</p>
        </div>
      </div>

      <div class="facility-card">
        <img src="https://www.classiciasacademy.com/blog/wp-content/uploads/2019/06/Sanitation-in-Schools-India.jpg" alt="Medical Room">
        <div class="facility-content">
          <h3>Medical & Hygiene</h3>
          <p>Medical room with trained nurse, clean toilets, and hygiene monitoring ensure student wellness.</p>
        </div>
      </div>

      <div class="facility-card">
        <img src="https://www.shutterstock.com/image-photo/tangerang-indonesia-june-11-2025-600nw-2639558379.jpg" alt="Green Campus">
        <div class="facility-content">
          <h3>Clean & Green Campus</h3>
          <p>Eco-friendly campus with solar panels, gardens, and rainwater harvesting initiatives.</p>
        </div>
      </div>

    </div>
  </section>
<?php include('include/footer.php')?>
</body>
</html>
