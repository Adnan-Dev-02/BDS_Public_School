<?php include('include/navbar.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Our Staff | B.D.S Public School</title>
<link rel="stylesheet" href="/assets/css/staff.css">
<link rel="icon" href="assets/Photo/logo.png" type="image/x-icon">
</head>
<body>
 <section>
    <h2>Our Teaching Staff</h2>
    <div class="staff-grid">
      <div class="staff-card">
        <img src="https://source.unsplash.com/400x300/?teacher,woman" alt="Teacher">
        <div class="staff-info">
          <h3>Mrs. Anita Sharma</h3>
          <p>Principal</p>
          <p>25+ years of educational leadership experience.</p>
        </div>
      </div>
      <div class="staff-card">
        <img src="https://source.unsplash.com/400x300/?teacher,man" alt="Teacher">
        <div class="staff-info">
          <h3>Mr. Rakesh Yadav</h3>
          <p>Maths Faculty</p>
          <p>Expert in algebra, calculus and problem-solving.</p>
        </div>
      </div>

      <div class="staff-card">
        <img src="https://source.unsplash.com/400x300/?science,teacher" alt="Science Teacher">
        <div class="staff-info">
          <h3>Dr. Pooja Verma</h3>
          <p>Science Faculty</p>
          <p>Specializes in Physics and hands-on experiments.</p>
        </div>
      </div>

      <div class="staff-card">
        <img src="https://source.unsplash.com/400x300/?computer,teacher" alt="Computer Teacher">
        <div class="staff-info">
          <h3>Mr. Arjun Kapoor</h3>
          <p>Computer Instructor</p>
          <p>Teaches coding, IT, and computer applications.</p>
        </div>
      </div>

      <div class="staff-card">
        <img src="https://source.unsplash.com/400x300/?music,teacher" alt="Music Teacher">
        <div class="staff-info">
          <h3>Ms. Rina George</h3>
          <p>Music & Arts</p>
          <p>Engages students with creativity and performance.</p>
        </div>
      </div>

      <div class="staff-card">
        <img src="https://source.unsplash.com/400x300/?sports,coach" alt="Sports Coach">
        <div class="staff-info">
          <h3>Coach Vinay Singh</h3>
          <p>Physical Education</p>
          <p>Promotes fitness and sportsmanship among students.</p>
        </div>
      </div>

    </div>
  </section>
  <script>
// Right Click Disable
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Text Selection Disable
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
});

// Copy, Cut, Paste Disable
document.addEventListener('copy', function(e) {
    e.preventDefault();
});
document.addEventListener('cut', function(e) {
    e.preventDefault();
});
document.addEventListener('paste', function(e) {
    e.preventDefault();
});

// Keyboard Shortcuts Disable (Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I etc.)
document.addEventListener('keydown', function(e) {
    if (
        (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's' || e.key === 'a')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'j')) ||
        (e.key === 'F12')
    ) {
        e.preventDefault();
    }
});
</script>

<?php include('include/footer.php')?>
</body>
</html>
