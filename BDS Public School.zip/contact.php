<?php include('include/navbar.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Us | B.D.S Public School</title>
  <link rel="stylesheet" href="/assets/css/contact.css">
  <link rel="icon" href="assets/Photo/logo.png" type="image/x-icon">
</head>
<body>
  <!-- Contact Section -->
  <section>
    <h2>Contact Us</h2>
    <div class="contact-container">
      <!-- Contact Info -->
      <div class="contact-info">
        <h3>📍 School Address</h3>
        <p><strong>Location:</strong> Fattupur (Babura) Badlapur,Jaunpur, UP, India</p>
        <p><strong>Email:</strong> contact@bdsschool.in</p>
        <p><strong>Phone:</strong> +91-8081367661</p>
        <p><strong>Working Hours:</strong> Mon–Sat, 8 AM – 2 PM</p>
        <p><strong>Admission Enquiry:</strong> +91-8081367661</p>
        <p><strong>Careers:</strong> hr@bdsschool.in</p>
      </div>

      <!-- Contact Form -->
      <div class="contact-form">
        <h3>✉️ Send Us a Message</h3>
        <form onsubmit="return sendMessage(event)">
          <input type="text" placeholder="Your Full Name" required />
          <input type="email" placeholder="Your Email Address" required />
          <textarea rows="5" placeholder="Your Message" required></textarea>
          <button type="submit">Send Message</button>
        </form>
      </div>
    </div>

    <!-- Embedded Map -->
  <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3588.810755474846!2d82.4247200754053!3d25.908590977259898!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMjXCsDU0JzMwLjkiTiA4MsKwMjUnMzguMyJF!5e0!3m2!1sen!2sin!4v1768893209195!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  </section>

  <!-- JS -->
  <script>
    function sendMessage(e) {
      e.preventDefault();
      alert("✅ Your message has been sent! We will contact you shortly.");
      e.target.reset();
      return false;
    }
  </script>
  <script>
// Right Click Disable
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Text Selection Disable
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
});

// Copy, Cut, Paste Disable
document.addEventListener('copy', function(e) {
    e.preventDefault();
});
document.addEventListener('cut', function(e) {
    e.preventDefault();
});
document.addEventListener('paste', function(e) {
    e.preventDefault();
});

// Keyboard Shortcuts Disable (Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I etc.)
document.addEventListener('keydown', function(e) {
    if (
        (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's' || e.key === 'a')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'j')) ||
        (e.key === 'F12')
    ) {
        e.preventDefault();
    }
});
</script>

<?php include('include/footer.php')?>
</body>
</html>
