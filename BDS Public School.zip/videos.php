<?php

include('include/navbar.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Videos | B.D.S Public School</title>
  <link rel="stylesheet" href="/assets/css/videos.css" />
  <link rel="icon" href="assets/Photo/logo.png" type="image/x-icon">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
    }

    .video-page-container {
      max-width: 1200px;
      margin: 40px auto;
      padding: 0 20px;
    }

    .video-page-container h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #004080;
    }

    .video-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 20px;
    }

    .video-grid iframe, .video-grid video {
      width: 100%;
      height: 200px;
      border: none;
      border-radius: 8px;
    }

    @media (min-width: 768px) {
      .video-grid iframe, .video-grid video {
        height: 250px;
      }
    }
  </style>
</head>
<body>

  <!-- 📹 Video Section -->
  <div class="video-page-container">
    <h2>Campus Videos & Highlights</h2>
    <div class="video-grid">
      <!-- YouTube Embed -->
      <iframe src="assets/video/1.mp4" allowfullscreen></iframe>
    <!-- Another YouTube Embed -->
  <iframe src="assets/video/2.mp4" allowfullscreen></iframe>

      <!-- Local Video Example -->
      <video controls>
        <source src="assets/video/3.mp4" type="video/mp4">
        Your browser does not support the video tag.
      </video>

      <!-- Another Local Video -->
      <video controls>
        <source src="assets/video/.mp4" type="video/mp4">
        Your browser does not support the video tag.
      </video>
    </div>
  </div>
<script>
// Right Click Disable
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Text Selection Disable
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
});

// Copy, Cut, Paste Disable
document.addEventListener('copy', function(e) {
    e.preventDefault();
});
document.addEventListener('cut', function(e) {
    e.preventDefault();
});
document.addEventListener('paste', function(e) {
    e.preventDefault();
});

// Keyboard Shortcuts Disable (Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I etc.)
document.addEventListener('keydown', function(e) {
    if (
        (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's' || e.key === 'a')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'j')) ||
        (e.key === 'F12')
    ) {
        e.preventDefault();
    }
});
</script>

  <?php include('include/footer.php'); ?>

</body>
</html>
