<footer>
    <div
        style="
        max-width: 1800px; 
        margin: auto; 
        padding: 30px 20px;
         display: flex;
          flex-wrap: wrap;
           justify-content: space-between; 
           gap: 30px;
           background-color: #004080;">

        <!-- About -->
        <div style="flex: 1 1 250px;">
            <h3 style="color: #ffcc00;">About B.D.S Public School</h3>
            <p style="margin: 10px 0; color: #ccc;">
                B.D.S Public School is a CBSE-affiliated institution dedicated to academic excellence and holistic
                development since 2005.
            </p>
        </div>

        <!-- Quick Links -->
        <div style="flex: 1 1 200px;">
            <h3 style="color: #ffcc00;">Quick Links</h3>
            <ul style="list-style: none; padding: 0; color: #ccc; line-height: 1.8;">
                <li><a href="#about" style="color: #ccc; text-decoration: none;">About Us</a></li>
                <li><a href="#admission" style="color: #ccc; text-decoration: none;">Admissions</a></li>
                <li><a href="#academics" style="color: #ccc; text-decoration: none;">Academics</a></li>
                <li><a href="#facilities" style="color: #ccc; text-decoration: none;">Facilities</a></li>
                <li><a href="#gallery" style="color: #ccc; text-decoration: none;">Gallery</a></li>
                <li><a href="#contact" style="color: #ccc; text-decoration: none;">Contact</a></li>
            </ul>
        </div>

        <!-- Contact Info -->
        <div style="flex: 1 1 250px;">
            <h3 style="color: #ffcc00;">Contact Us</h3>
            <p style="color: #ccc;">📍 Fattupur (Babura) Badlapur,Jaunpur UP, India</p>
            <p style="color: #ccc;">📞 +91-8081367661</p>
            <p style="color: #ccc;">⏰ Mon–Sat, 8 AM – 2 PM</p>
        </div>

        <!-- Newsletter
        <div style="flex: 1 1 280px;">
            <h3 style="color: #ffcc00;">Subscribe Newsletter</h3>
            <p style="color: #ccc;">Get latest news and updates right in your inbox.</p>
            <form onsubmit="return subscribeNewsletter(event)">
                <input type="email" id="newsletterEmail" placeholder="Enter your email" required
                    style="padding: 10px; border: none; border-radius: 5px; width: 80%; margin-bottom: 10px;">
                <br>
                <button type="submit"
                    style="padding: 10px 20px; background-color: #ff9800; color: white; border: none; border-radius: 5px; cursor: pointer;">
                    Subscribe
                </button>
            </form>
        </div>
    </div> -->

    <!-- Social + Copyright -->
    <!-- <div style="text-align: center; padding: 20px 10px; background-color: #111; border-top: 1px solid #444;">
        <p style="color: #ccc; margin-bottom: 10px;">Follow Us:</p>
        <div style="margin-bottom: 15px;">
            <a href="#" title="Facebook" style="color: white; margin: 0 10px; font-size: 1.2rem;">🌐</a>
            <a href="#" title="Twitter" style="color: white; margin: 0 10px; font-size: 1.2rem;">🐦</a>
            <a href="#" title="Instagram" style="color: white; margin: 0 10px; font-size: 1.2rem;">📷</a>
            <a href="#" title="LinkedIn" style="color: white; margin: 0 10px; font-size: 1.2rem;">💼</a>
        </div>
        <p style="color: #888;">&copy; 2025 B.D.S Public School | Designed for Education | All Rights Reserved</p>
    </div> -->

    <script>
        function subscribeNewsletter(event) {
            event.preventDefault();
            const email = document.getElementById('newsletterEmail').value.trim();
            if (email) {
                alert("Thank you for subscribing, " + email);
                document.getElementById('newsletterEmail').value = '';
            }
        }
    </script>
</footer>