<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>B.D.S Public School</title>
<link rel="icon" href="assets/Photo/logo.png" type="image/x-icon">
<style>
/* Disturbance hatane ke liye body aur main classes ka use */
.bds-main-site { 
    background: #fdfdfd; 
    margin: 0; 
    padding: 0; 
    font-family: Arial, sans-serif; 
    overflow-x: hidden;
}

/* ===== HEADER ===== */
.bds-header { 
    background:#004080; 
    color:white; 
    text-align:center; 
    padding:20px 10px; 
    position:relative; 
}
.bds-logo { 
    width:85px; height:85px; 
    border-radius:50%; 
    position:absolute; left:40px; top:12px; 
    background:#FFFDD0; border: 2px solid #fff; 
    z-index: 10;
}
.bds-header h1 { font-size: 32px; margin: 0; padding-bottom: 5px; }
.bds-header p { font-size: 16px; margin: 0; opacity: 0.9; }

/* ===== NOTICE BAR ===== */
.bds-notice-bar { background:orange; color:white; padding:10px 0; font-size: 16px; font-weight: bold; text-align: center; }

/* ===== NAVBAR FIX (Menu ko wapas lane ke liye) ===== */
.bds-nav { background:#004080; position: relative; z-index: 9999; border-top: 1px solid rgba(255,255,255,0.1); }
.bds-nav-container { 
    max-width:1200px; margin:auto; padding:0 15px; 
    display:flex; align-items:center; justify-content:space-between; height: 60px; 
}
.bds-nav-brand { color: white; font-weight: bold; font-size: 20px; text-decoration: none; }

.bds-menu { display:flex !important; list-style:none !important; margin: 0 !important; padding: 0 !important; }
.bds-menu li { position:relative; list-style: none !important; margin: 0; padding: 0; }
.bds-menu a { 
    display:block; padding:18px 22px; color:white; 
    text-decoration:none; font-size: 17px; font-weight: 500; 
}
.bds-menu a:hover { background: rgba(255,255,255,0.15); }

/* DROPDOWN ALIGNMENT */
.bds-menu li ul { 
    display:none; position:absolute; top:100%; left: 0; 
    background:#ff7b00; min-width:220px; box-shadow: 0 8px 15px rgba(0,0,0,0.2); 
    padding: 0; margin: 0; list-style: none;
}
.bds-menu li:hover > ul { display:block; }
.bds-menu li ul li a { padding: 14px 20px; font-size: 16px; border-bottom: 1px solid rgba(0,0,0,0.05); }

/* MOBILE TOGGLE */
.bds-toggle { display:none; flex-direction:column; cursor:pointer; }
.bds-toggle span { height:3px; width:28px; background:white; margin:3px 0; }

/* ===== ABOUT SECTION (AS PER IMAGE) ===== */
.bds-about { padding: 60px 0; background: white; }
.bds-about-container { 
    max-width: 1200px; margin: 0 auto; display: flex; 
    align-items: center; gap: 40px; padding: 0 20px; flex-wrap: wrap; 
}

.bds-about-images { flex: 1; display: grid; grid-template-columns: 1fr 1fr; gap: 15px; min-width: 320px; }
.bds-img-box { width: 100%; height: 180px; border-radius: 15px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
.bds-img-box img { width: 100%; height: 100%; object-fit: cover; display: block; }

.bds-circle-frame { 
    border-radius: 50% !important; border: 4px dashed #ff5e14; padding: 6px; 
    height: 180px; width: 180px; margin: auto; overflow: hidden;
}
.bds-circle-frame img { border-radius: 50%; width: 100%; height: 100%; object-fit: cover; }

.bds-about-text { flex: 1.2; min-width: 350px; }
.bds-about-text h2 { font-size: 42px; color: #004080; margin: 0 0 20px 0; line-height: 1.1; font-weight: 800; }
.bds-about-text span { color: #ff5e14; }
.bds-about-text p { font-size: 18px; color: #555; line-height: 1.7; margin-bottom: 25px; }

/* ===== MOBILE VIEW ===== */
@media(max-width:768px) {
    .bds-logo { width:55px; height:55px; left:15px; top:12px; }
    .bds-header h1 { font-size: 22px; margin-left: 55px; }
    .bds-header p { font-size: 13px; margin-left: 55px; }
    
    .bds-toggle { display:flex; }
    .bds-menu { 
        display:none !important; position: absolute; top: 60px; left: 0; width: 100%; 
        flex-direction: column; background: #004080; padding: 0; margin: 0; 
    }
    .bds-menu.active { display:flex !important; }
    .bds-menu a { padding: 18px 25px; font-size: 18px; border-bottom: 1px solid rgba(255,255,255,0.1); }
    
    .bds-menu li ul { position: static; display: none; width: 100%; box-shadow: none; }
    .bds-menu li.open > ul { display: block; }

    .bds-about-container { flex-direction: column; padding: 0; }
    .bds-about-images { grid-template-columns: 1fr; width: 100%; gap: 10px; }
    .bds-img-box { height: 260px; border-radius: 0; }
    .bds-circle-frame { width: 220px; height: 220px; margin: 20px auto; border-radius: 50% !important; }
    .bds-about-text { padding: 25px; text-align: center; }
}
</style>
</head>
<body class="bds-main-site">

<header class="bds-header">
  <img src="assets/Photo/logo.png" class="bds-logo" alt="logo">
  <h1>B.D.S Public School</h1>
  <p>Empowering Future Leaders Since 2005</p>
</header>

<div class="bds-notice-bar">
  <marquee scrollamount="5">🎉 Welcome to B.D.S Public School | Admissions Open 2025–26</marquee>
</div>

<nav class="bds-nav">
  <div class="bds-nav-container">
    <div class="bds-nav-brand"> Academic session : <label id="academicSession"></label></div>
    <div class="bds-toggle" onclick="toggleMenu()">
      <span></span><span></span><span></span>
    </div>
    <ul class="bds-menu" id="bdsMenu">
      <li><a href="index.php">Home</a></li>
      <li onclick="toggleSubMenu(this)">
        <a href="javascript:void(0)">About Us ▾</a>
        <ul>
           <li><a href="vision.php">Vision & Mission</a></li>
           <li><a href="history.php">School History</a></li>
           <li><a href="principal.php">Principal's Message</a></li>
        </ul>
      </li>
      <li><a href="Teach.php">Staff</a></li>
      <li onclick="toggleSubMenu(this)">
        <a href="javascript:void(0)">Gallery ▾</a>
        <ul>
          <li><a href="photos.php">Event Photos</a></li>
          <li><a href="videos.php">Event Videos</a></li>
        </ul>
      </li>
      <li><a href="contact.php">Contact Us</a></li>
      <li><a href="Facilities.php">Facilities</a></li>
    </ul>
  </div>
</nav>



<script>
function toggleMenu(){
  var menu = document.getElementById("bdsMenu");
  if (menu.classList.contains("active")) {
      menu.classList.remove("active");
  } else {
      menu.classList.add("active");
  }
}

function toggleSubMenu(item){
  if(window.innerWidth <= 768){
    item.classList.toggle("open");
  }
}
</script>






















<script>
    function getAcademicSession() {
        const today = new Date();
        const year = today.getFullYear();
        const month = today.getMonth(); // Jan = 0, Apr = 3

        // Academic session usually starts from April
        let startYear, endYear;

        if (month >= 3) { // April or later
            startYear = year;
            endYear = year + 1;
        } else {
            startYear = year - 1;
            endYear = year;
        }

        return startYear + "–" + endYear.toString().slice(-2);
    }

    document.getElementById("academicSession").textContent =
        getAcademicSession();
</script>












</body>
</html>