<?php include('include/navbar.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Photo Gallery | B.D.S Public School</title>
  <link rel="stylesheet" href="/assets/css/photos.css" />
  <link rel="icon" href="assets/Photo/logo.png" type="image/x-icon">
  <style>
    body{
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f8f8f8;
    }

    .gallery-container {
      max-width: 1200px;
      margin: 40px auto;
      padding: 0 20px;
    }

    .gallery-container h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #004080;
    }

    .photo-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
    }

    .photo-grid img {
      width: 100%;
      height: 180px;
      object-fit: cover;
      border-radius: 8px;
      cursor: pointer;
      transition: transform 0.3s ease;
    }

    .photo-grid img:hover {
      transform: scale(1.05);
    }

    /* Fullscreen Overlay */
    .overlay {
      position: fixed;
      display: none;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background-color: rgba(107, 238, 0, 0.42);
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .overlay img {
      max-width: 90%;
      max-height: 90%;
      border: 5px solid white;
      border-radius: 10px;
    }

    .overlay:active {
      display: none;
    }

    .overlay-close {
      position: absolute;
      top: 20px;
      right: 30px;
      font-size: 30px;
      color: white;
      cursor: pointer;
    }

    @media (max-width: 600px) {
      .photo-grid img {
        height: 150px;
      }
    }
  </style>
</head>
<body>

<!-- 🖼️ Gallery Section -->
<div class="gallery-container">
  <h2>School Photo Gallery</h2>
  <div class="photo-grid">
    <!-- Replace with your image paths -->
    <img src="assets/Photo/1.jpeg" alt="Event 1" onclick="openOverlay(this.src)">
    <img src="assets/Photo/3.jpeg" alt="Event 3" onclick="openOverlay(this.src)">
    <img src="assets/Photo/4.jpeg" alt="Event 4" onclick="openOverlay(this.src)">
    <img src="assets/Photo/5.jpeg" alt="Event 5" onclick="openOverlay(this.src)">
    <img src="assets/Photo/6.jpeg" alt="Event 6" onclick="openOverlay(this.src)">

    <img src="assets/Photo/7.jpeg" alt="Event 1" onclick="openOverlay(this.src)">
    <img src="assets/Photo/8.jpeg" alt="Event 2" onclick="openOverlay(this.src)">
    <img src="assets/Photo/9.jpeg" alt="Event 3" onclick="openOverlay(this.src)">
    <img src="assets/Photo/10.jpeg" alt="Event 4" onclick="openOverlay(this.src)">
    <img src="assets/Photo/11.jpeg" alt="Event 5" onclick="openOverlay(this.src)">
    <img src="assets/Photo/12.jpeg" alt="Event 6" onclick="openOverlay(this.src)">

    <img src="assets/Photo/13.jpeg" alt="Event 1" onclick="openOverlay(this.src)">
    <img src="assets/Photo/14.jpeg" alt="Event 2" onclick="openOverlay(this.src)">
    <img src="assets/Photo/15.jpeg" alt="Event 3" onclick="openOverlay(this.src)">
    <img src="assets/Photo/16.jpeg" alt="Event 4" onclick="openOverlay(this.src)">
    <img src="assets/Photo/17.jpeg" alt="Event 5" onclick="openOverlay(this.src)">
    <img src="assets/Photo/18.jpeg" alt="Event 6" onclick="openOverlay(this.src)">

    <img src="assets/Photo/19.jpeg" alt="Event 1" onclick="openOverlay(this.src)">
    <img src="assets/Photo/20.jpeg" alt="Event 2" onclick="openOverlay(this.src)">
    <img src="assets/Photo/21.jpeg" alt="Event 3" onclick="openOverlay(this.src)">
    <img src="assets/Photo/22.jpeg" alt="Event 4" onclick="openOverlay(this.src)">
    <img src="assets/Photo/23.jpeg" alt="Event 5" onclick="openOverlay(this.src)">
    <img src="assets/Photo/24.jpeg" alt="Event 3" onclick="openOverlay(this.src)">
    <img src="assets/Photo/25.jpeg" alt="Event 4" onclick="openOverlay(this.src)">
    <img src="assets/Photo/26.jpeg" alt="Event 5" onclick="openOverlay(this.src)">
  </div>
</div>

<!-- 🔍 Fullscreen Overlay -->
<div class="overlay" id="photoOverlay" onclick="closeOverlay()">
  <span class="overlay-close" onclick="closeOverlay()">×</span>
  <img id="overlayImage" src="" alt="Full View">
</div>

<?php include('include/footer.php'); ?>

<!-- 📜 Script -->
<script>
  function openOverlay(src) {
    const overlay = document.getElementById("photoOverlay");
    const image = document.getElementById("overlayImage");
    image.src = src;
    overlay.style.display = "flex";
  }

  function closeOverlay() {
    document.getElementById("photoOverlay").style.display = "none";
  }
</script>
<script>
// Right Click Disable
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Text Selection Disable
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
});

// Copy, Cut, Paste Disable
document.addEventListener('copy', function(e) {
    e.preventDefault();
});
document.addEventListener('cut', function(e) {
    e.preventDefault();
});
document.addEventListener('paste', function(e) {
    e.preventDefault();
});

// Keyboard Shortcuts Disable (Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I etc.)
document.addEventListener('keydown', function(e) {
    if (
        (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's' || e.key === 'a')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'j')) ||
        (e.key === 'F12')
    ) {
        e.preventDefault();
    }
});
</script>


</body>
</html>
