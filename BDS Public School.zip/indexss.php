<?php include ('include/navbar.php')?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/banner.css">
    
<link rel="icon" href="assets/Photo/logo.png" type="image/x-icon">
<style>
    .logo{
  width:94px;
  height:94px;
  border-radius:50%;
  position:absolute;
  left:35px;
  top:10px;
  background:#FFFDD0;
}
@media(max-width:768px){
        .logo{
  width:44px;
  height:44px;
  border-radius:50%;
  position:absolute;
  left:4px;
  top:17px;
  background:#FFFDD0;
}
    
}

</style>
</head>
<body>
    <!-- Banner Overlay -->
<div class="overlay" id="overlay">
    <div class="banner">
        <button class="close-btn" onclick="closeBanner()">×</button>
        <img src="assets/Photo/1.jpeg" alt="Banner">
    </div>
</div>
<div id="schoolSlider" class="carousel slide carousel-fade" data-bs-ride="carousel">
         <div class="carousel-indicators">
        <button type="button" data-bs-target="#schoolSlider" data-bs-slide-to="0" class="active"></button>
        <button type="button" data-bs-target="#schoolSlider" data-bs-slide-to="1"></button>
        <button type="button" data-bs-target="#schoolSlider" data-bs-slide-to="2"></button>
        <button type="button" data-bs-target="#schoolSlider" data-bs-slide-to="3"></button>
    </div>

    <div class="carousel-inner">
        <div class="carousel-item active" data-bs-interval="4000">
            <img src="assets/Photo/16.jpeg" alt="Classroom">
            <!-- <div class="carousel-caption">
                <h2>Modern Learning</h2>
                <p>Equipping students with 21st-century skills in a creative environment.</p>
                <a href="#" class="btn-orange">ADMISSION OPEN</a>
            </div> -->
        </div>

        <div class="carousel-item" data-bs-interval="4000">
            <img src="assets/Photo/13.jpeg" alt="Playground">
            <!-- <div class="carousel-caption">
                <h2>Sports & Health</h2>
                <p>Developing teamwork and physical excellence through daily sports activities.</p>
                <a href="#" class="btn-orange">OUR CAMPUS</a>
            </div> -->
        </div>

        <div class="carousel-item" data-bs-interval="4000">
            <img src="assets/Photo/14.jpeg" alt="Science Lab">
            <!-- <div class="carousel-caption">
                <h2>Science & Tech</h2>
                <p>Exploring the wonders of science in our high-tech laboratories.</p>
                <a href="#" class="btn-orange">VIEW FACILITIES</a>
            </div> -->
        </div>

        <div class="carousel-item" data-bs-interval="4000">
            <img src="assets/Photo/15.jpeg" alt="Library">
            <!-- <div class="carousel-caption">
                <h2>Digital Library</h2>
                <p>A vast collection of knowledge to fuel the curious minds of our students.</p>
                <a href="#" class="btn-orange">READ MORE</a>
            </div> -->
        </div>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#schoolSlider" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#schoolSlider" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
    </button>
</div>
<!-- /**part 2 about session */ -->
<section class="about-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-5 mb-lg-0">
                    <div class="row g-3">
                        <div class="col-7">
                            <img src="assets/Photo/3.jpeg" class="img-rounded-custom" alt="School Activity">
                            <img src="assets/Photo/7.jpeg" class="rounded-4 w-100" style="height:150px; object-fit:cover;margin-top:20px">
                        </div>
                        <div class="col-5">
                            <div class="img-circle-frame mb-3">
                                <img src="assets/Photo/4.jpeg" class="rounded-circle" width="150" height="150" style="object-fit:cover;">
                            </div>
                            <img src="assets/Photo/5.jpeg" class="rounded-4 w-100" style="height:150px; object-fit:cover;margin-top:20px">
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-6 ps-lg-5">
                    <h6 class="text-orange fw-bold">ABOUT US</h6>
                    <h2 class="text-blue display-5 fw-bold mb-4">Welcome To <span class="text-orange">B.D.S Public</span> School.</h2>
                    <p class="text-muted mb-4">B.D.S Public School is one of the most gracious and respectable names in school education. This world-class CBSE affiliated school is situated in a safe & secure residential area.</p>
                    
                    <div class="d-flex align-items-center mb-4">
                        <div class="me-3 p-3 bg-light rounded-circle text-orange">
                            <svg width="30" height="30" fill="currentColor" viewBox="0 0 16 16"><path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zM4.5 7.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1H5a.5.5 0 0 1-.5-.5z"/></svg>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-bold">Outcomes of B.D.S Public School Education</h6>
                            <small class="text-muted">There are vastly different real-world demands...</small>
                        </div>
                    </div>

                    <div class="d-flex gap-3 align-items-center">
                        <button class="btn-orange">READ MORE →</button>
                        <div class="ps-3 border-start">
                            <small class="d-block text-muted">Call Now</small>
                            <h6 class="text-blue fw-bold">+91-8081367661</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="counter-section">
        <div class="container">
            <div class="row text-center">
                <div class="col-6 col-md-3 stat-card">
                    <div class="icon-box">
                        <svg width="30" height="30" fill="white" viewBox="0 0 16 16"><path d="M1 2.828c.885-.37 2.154-.769 3.388-.893 1.33-.134 2.458.063 3.112.752v9.746c-.935-.53-2.12-.603-3.213-.493-1.18.12-2.37.461-3.287.811V2.828zm7.5-.141c.654-.689 1.782-.886 3.112-.752 1.234.124 2.503.523 3.388.893v9.923c-.918-.35-2.107-.692-3.287-.81-1.094-.111-2.278-.039-3.213.492V2.687zM8 1.783C7.015.936 5.587.81 4.287.94c-1.514.153-3.042.672-3.994 1.105A.5.5 0 0 0 0 2.5v11a.5.5 0 0 0 .707.455c.882-.4 2.303-.881 3.68-1.02 1.409-.142 2.59.087 3.223.877a.5.5 0 0 0 .78 0c.633-.79 1.814-1.019 3.222-.877 1.378.139 2.8.62 3.681 1.02A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.293-.455c-.952-.433-2.48-.952-3.994-1.105C10.413.809 8.985.936 8 1.783z"/></svg>
                    </div>
                    <span class="counter-val" data-target="18">0</span>
                    <p class="counter-label">+ Total Subjects</p>
                </div>
                <div class="col-6 col-md-3 stat-card">
                    <div class="icon-box">
                        <svg width="30" height="30" fill="white" viewBox="0 0 16 16"><path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H7zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM2 9s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H2zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/></svg>
                    </div>
                    <span class="counter-val" data-target="870">0</span>
                    <p class="counter-label">+ Our Students</p>
                </div>
                <div class="col-6 col-md-3 stat-card">
                    <div class="icon-box">
                        <svg width="30" height="30" fill="white" viewBox="0 0 16 16"><path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/></svg>
                    </div>
                    <span class="counter-val" data-target="75">0</span>
                    <p class="counter-label">+ Skilled Lecturers</p>
                </div>
                <div class="col-6 col-md-3 stat-card">
                    <div class="icon-box">
                        <svg width="30" height="30" fill="white" viewBox="0 0 16 16"><path d="M2.5.5A.5.5 0 0 1 3 0h10a.5.5 0 0 1 .5.5c0 .538-.012 1.05-.034 1.536a3 3 0 1 1-1.133 5.89c-.79 1.865-1.878 2.777-2.833 3.011v2.173l1.425.356c.194.048.377.135.537.255L13.3 15.1a.5.5 0 0 1-.3.9H3a.5.5 0 0 1-.3-.9l1.838-1.379c.16-.12.343-.207.537-.255L6.5 13.111v-2.173c-.955-.234-2.043-1.146-2.833-3.012a3 3 0 1 1-1.132-5.89A33.776 33.776 0 0 1 2.5.5zm.5 1.037c.012.445.025.924.039 1.432a2 2 0 0 0 1.074 3.992c.627 1.856 1.623 2.592 2.394 2.823a.5.5 0 0 1 .356.48v2.66l-.587.146a1.5 1.5 0 0 0-.806.383L4.146 15h7.708l-1.332-1a1.5 1.5 0 0 0-.806-.384l-.587-.146v-2.66a.5.5 0 0 1 .356-.48c.77-.23 1.767-.967 2.394-2.823a2 2 0 0 0 1.074-3.992c.014-.508.027-.987.039-1.432H3zM1.5 3a1 1 0 0 1 1-1h.25c.03 1.157.073 2.158.126 3.047a2 2 0 1 1-1.376-2.047zM14 2a1 1 0 0 1 1 1 2 2 0 1 1-1.377 2.047c.053-.889.096-1.89.127-3.047H14z"/></svg>
                    </div>
                    <span class="counter-val" data-target="30">0</span>
                    <p class="counter-label">+ Win Awards</p>
                </div>
            </div>
        </div>
    </section>
<section class="video-section">

    <!-- LEFT CONTENT -->
    <div class="content-box">
        <span class="sub-title">LATEST VIDEO</span>
        <h2>Let's   <span>Check Our</span><br>Latest Video</h2>
        <p>
            Discover the vibrant campus life, modern classrooms, and the spirit of
            excellence at Green Valley College. Watch our latest video to see how we
            shape future leaders through innovation and tradition.
        </p>
        <a href="#" class="learn-btn">LEARN MORE <i class="fas fa-arrow-right"></i></a>
    </div>

    <!-- RIGHT VIDEO -->
    <div class="video-wrapper">
        <div class="video-container">
            <img src="assets/Photo/19.jpeg">
            <div class="play-btn">
                <span><i class="fas fa-play"></i></span>
            </div>
            <video controls>
                <source src="assets/video/3.mp4" type="video/mp4">
            </video>
        </div>
    </div>
</section>


<!-- /*part 3 our classes*/ -->
<section class="classes-section">
    <div class="container">
        <span class="section-tag">Our Classes</span>
        <h2 class="main-heading">Let's Check Our <span>Classes</span></h2>
        <p class="sub-text">
            B.D.S public schoo is a learning school. We provide an open environment for our students to express themselves, a myriad of opportunities to spread their wings, and support their highest aspirations.
        </p>

        <div class="row g-4">
            <div class="col-lg-3 col-md-6">
                <div class="class-card">
                    <div class="img-container">
                        <img src="assets/Photo/23.jpeg" alt="Pre-primary">
                        <!-- <span class="class-badge">joyful years</span> -->
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Pre-primary Grades</h5>
                        <p class="card-desc">B.D.S public schoo has developed as a warm and caring school community that prepares children for life, not just exams.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="class-card">
                    <div class="img-container">
                        <img src="assets/Photo/7.jpeg" alt="Primary">
                        <!-- <span class="class-badge">empowering years</span> -->
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Primary Grades</h5>
                        <p class="card-desc">B.D.S public schoo believes in empowering students in the primary years by giving them ownership. This helps in vertical alliance.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="class-card">
                    <div class="img-container">
                        <img src="assets/Photo/8.jpeg" alt="Middle">
                        <!-- <span class="class-badge">inspiring years</span> -->
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Middle Grades</h5>
                        <p class="card-desc">The B.D.S public schoo environment is rife with possibilities for the students. A huge range of pedagogical learning materials are arranged.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="class-card">
                    <div class="img-container">
                        <img src="assets/Photo/10.jpeg" alt="Senior">
                        <!-- <span class="class-badge">victorious years</span> -->
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Senior Grades</h5>
                        <p class="card-desc">Performance in Boards and preparation for a life of service. High quality education with a balanced approach.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

     <section class="gallery-header">
        <div class="container">
            <p class="text-uppercase fw-bold text-orange" style="letter-spacing: 2px; color: var(--primary-orange);">Memories</p>
            <h1>Our <span>Gallery</span></h1>
       </div>
    </section>

    <div class="container pb-5">
        
        <div class="filter-container">
            <button class="filter-btn active" onclick="filterGallery('all')">All Photos</button>
            <button class="filter-btn" onclick="filterGallery('campus')">Campus</button>
            <button class="filter-btn" onclick="filterGallery('sports')">Events 1</button>
            <button class="filter-btn" onclick="filterGallery('events')">Events 2</button>
            <button class="filter-btn" onclick="filterGallery('lab')">Events 3</button>
        </div>

        <div class="row" id="gallery-grid">
            <div class="col-lg-4 col-md-6 gallery-item campus">
                <div class="gallery-box">
                    <img src="assets/Photo/23.jpeg" alt="Campus">
                    <div class="gallery-overlay">
                        <div class="overlay-content text-center">
                            <h5>School Campus</h5>
                            <p>Assembly Ground</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 gallery-item sports">
                <div class="gallery-box">
                    <img src="assets/Photo/11.jpeg" alt="Sports">
                    <div class="gallery-overlay">
                        <div class="overlay-content text-center">
                            <h5>Event</h5>
                            <p>Cellebration 1</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 gallery-item sports">
                <div class="gallery-box">
                    <img src="assets/Photo/24.jpeg" alt="Sports">
                    <div class="gallery-overlay">
                        <div class="overlay-content text-center">
                            <h5>Event</h5>
                            <p>Cellebration 1</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 gallery-item sports">
                <div class="gallery-box">
                    <img src="assets/Photo/25.jpeg" alt="Sports">
                    <div class="gallery-overlay">
                        <div class="overlay-content text-center">
                            <h5>Event</h5>
                            <p>Cellebration 1</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 gallery-item sports">
                <div class="gallery-box">
                    <img src="assets/Photo/26.jpeg" alt="Sports">
                    <div class="gallery-overlay">
                        <div class="overlay-content text-center">
                            <h5>Event</h5>
                            <p>Cellebration 1</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 gallery-item lab">
                <div class="gallery-box">
                    <img src="assets/Photo/12.jpeg" alt="Lab">
                    <div class="gallery-overlay">
                        <div class="overlay-content text-center">
                            <h5>Event</h5>
                            <p>Cellebration 2</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 gallery-item events">
                <div class="gallery-box">
                    <img src="assets/Photo/13.jpeg" alt="Event">
                    <div class="gallery-overlay">
                        <div class="overlay-content text-center">
                           <h5>Event</h5>
                            <p>Cellebration 3</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 gallery-item sports">
                <div class="gallery-box">
                    <img src="assets/Photo/14.jpeg" alt="Sports">
                    <div class="gallery-overlay">
                        <div class="overlay-content text-center">
                           <h5>Event</h5>
                            <p>Cellebration 4</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 gallery-item events">
                <div class="gallery-box">
                    <img src="assets/Photo/15.jpeg" alt="Library">
                    <div class="gallery-overlay">
                        <div class="overlay-content text-center">
                           <h5>Event</h5>
                            <p>Cellebration 5</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- part 4 enrollment section -->
<section class="enroll-section">
    <div class="container">
        <div class="row align-items-center">
                <div class="col-lg-5">
                <div class="enroll-form-card">
                    <h3 class="form-title">Start Your Enrollment</h3>
                    <p class="form-subtitle">We are variations of passages we have suffered.</p>
                    
                    <form>
    <input type="text" class="form-control" placeholder="Your Name" id="name">
    <input type="tel" class="form-control" placeholder="Mobile No." id="mobile">
    <input type="email" class="form-control" placeholder="Email Address" id="email">
    <textarea class="form-control" rows="5" placeholder="Type Message" id="message"></textarea>

    <button type="button" class="btn-enroll" onclick="sendWhatsApp()">
        ENROLL NOW →
    </button>
</form>

                    
                    
                    
                    <!--<form>-->
                    <!--    <input type="text" class="form-control" placeholder="Your Name">-->
                    <!--    <input type="tel" class="form-control" placeholder="Mobile No." id="register" onchange="call()">-->
                    <!--    <input type="email" class="form-control" placeholder="Email Address">-->
                    <!--    <select class="form-select">-->
                    <!--        <option selected></option>-->
                    <!--        <option>Pre-primary</option>-->
                    <!--        <option>Primary</option>-->
                    <!--        <option>Senior</option>-->
                    <!--    </select>-->
                    <!--    <textarea class="form-control" rows="5" placeholder="Type Message" id="find"></textarea>-->
                    <!--    <button type="submit" class="btn-enroll">ENROLL NOW →</button>-->
                    <!--</form>-->
                </div>
            </div>
<div class="col-lg-7">
                <div class="content-box">
                    <span class="tag-line">Build Your Future</span>
                    <h2 class="main-heading"> <span class="text-black">Explore Your Creativity<br>And Talent With Us</span></h2>
                    
                    <div class="feature-list">
                        <div class="feature-item">
                            <h6>Collaboration</h6>
                            <p>Synergizing personalities, talents and knowledge for maximum results.</p>
                        </div>
                        <div class="feature-item">
                            <h6>Critical Thinking</h6>
                            <p>Filtering, analyzing, and questioning to solve complex problems.</p>
                        </div>
                        <div class="feature-item">
                            <h6>Communication</h6>
                            <p>Presenting information and thoughts in a clear and meaningful way.</p>
                        </div>
                        <div class="feature-item">
                            <h6>Creativity</h6>
                            <p>Innovating and creating something new using existing knowledge.</p>
                        </div>
                    </div>

                    <a href="#" class="btn-learn-more">LEARN MORE →</a>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- testimonials section -->
<section class="section-padding">
    <div class="container">
        
        <div class="header-text">
            <span>Testimonials</span>
            <h2>What Our Students <em>Say's</em></h2>
        </div>

        <div class="owl-carousel owl-theme" id="student-slider">
            
            <div class="item">
                <div class="testimonial-card">
                    <div class="quote-icon">“</div>
                    <div class="student-thumb">
                        <img src="https://i.pravatar.cc/150?u=1" alt="Student">
                    </div>
                    <div class="testimonial-content">
                        <p>The teachers are very supportive and the environment is perfect for learning new things every day.</p>
                        <div class="student-info">
                            <h5>Anjali Singh</h5>
                            <small>Class 10th</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="testimonial-card">
                    <div class="quote-icon">“</div>
                    <div class="student-thumb">
                        <img src="https://i.pravatar.cc/150?u=2" alt="Student">
                    </div>
                    <div class="testimonial-content">
                        <p>B.D.S public schoo has given me the platform to excel in both sports and academics.</p>
                        <div class="student-info">
                            <h5>Rahul Verma</h5>
                            <small>Class 8th</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="testimonial-card">
                    <div class="quote-icon">“</div>
                    <div class="student-thumb">
                        <img src="https://i.pravatar.cc/150?u=3" alt="Student">
                    </div>
                    <div class="testimonial-content">
                        <p>I love the library and the science lab here. Everything is so modern and well-maintained.</p>
                        <div class="student-info">
                            <h5>Sneha Gupta</h5>
                            <small>Class 12th</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="testimonial-card">
                    <div class="quote-icon">“</div>
                    <div class="student-thumb">
                        <img src="https://i.pravatar.cc/150?u=4" alt="Student">
                    </div>
                    <div class="testimonial-content">
                        <p>The extracurricular activities like debate and music have helped me build immense confidence.</p>
                        <div class="student-info">
                            <h5>Vikram Roy</h5>
                            <small>Class 9th</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="testimonial-card">
                    <div class="quote-icon">“</div>
                    <div class="student-thumb">
                        <img src="https://i.pravatar.cc/150?u=5" alt="Student">
                    </div>
                    <div class="testimonial-content">
                        <p>I feel safe and inspired at B.D.S public schoo. The digital classes make learning very easy and fun.</p>
                        <div class="student-info">
                            <h5>Priya Das</h5>
                            <small>Class 7th</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="testimonial-card">
                    <div class="quote-icon">“</div>
                    <div class="student-thumb">
                        <img src="https://i.pravatar.cc/150?u=6" alt="Student">
                    </div>
                    <div class="testimonial-content">
                        <p>Best school for someone who wants to balance studies with their passion for arts.</p>
                        <div class="student-info">
                            <h5>Sameer Khan</h5>
                            <small>Class 11th</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="testimonial-card">
                    <div class="quote-icon">“</div>
                    <div class="student-thumb">
                        <img src="https://i.pravatar.cc/150?u=7" alt="Student">
                    </div>
                    <div class="testimonial-content">
                        <p>The faculty here treats us like family. Their guidance is invaluable for our future.</p>
                        <div class="student-info">
                            <h5>Mehak Singh</h5>
                            <small>Class 10th</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="testimonial-card">
                    <div class="quote-icon">“</div>
                    <div class="student-thumb">
                        <img src="https://i.pravatar.cc/150?u=8" alt="Student">
                    </div>
                    <div class="testimonial-content">
                        <p>Modern campus with a traditional approach to values. Proud to be a B.D.S public schoo student.</p>
                        <div class="student-info">
                            <h5>Aditya Kumar</h5>
                            <small>Class 12th</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="testimonial-card">
                    <div class="quote-icon">“</div>
                    <div class="student-thumb">
                        <img src="https://i.pravatar.cc/150?u=9" alt="Student">
                    </div>
                    <div class="testimonial-content">
                        <p>The sports complex is huge! I've won many medals representing our school team.</p>
                        <div class="student-info">
                            <h5>Ishaan Malik</h5>
                            <small>Class 9th</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="testimonial-card">
                    <div class="quote-icon">“</div>
                    <div class="student-thumb">
                        <img src="https://i.pravatar.cc/150?u=10" alt="Student">
                    </div>
                    <div class="testimonial-content">
                        <p>Excellent preparation for competitive exams. The extra classes are very helpful.</p>
                        <div class="student-info">
                            <h5>Sanya Roy</h5>
                            <small>Class 11th</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script> -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>

<script>
function sendWhatsApp() {
    var name = document.getElementById("name").value;
    var mobile = document.getElementById("mobile").value;
    var email = document.getElementById("email").value;
    var message = document.getElementById("message").value;

    // Current Date & Time
    var now = new Date();
    var date = now.toLocaleDateString("en-IN");
    var time = now.toLocaleTimeString("en-IN");

    var whatsappNumber = "918081367661";

    var whatsappMessage =
        "📌 *New Enrollment Request* \n\n" +
        "👤 *Name:* " + name + "\n" +
        "📞 *Mobile:* " + mobile + "\n" +
        "📧 *Email:* " + email + "\n\n" +
        "💬 *Message:* \n" + message + "\n\n" +
        "📅 *Date:* " + date + "\n" +
        "⏰ *Time:* " + time + "\n\n" +
        "🚀 _Please contact soon_";

    var whatsappURL = "https://wa.me/" + whatsappNumber + "?text=" + encodeURIComponent(whatsappMessage);

    window.open(whatsappURL, "_blank");
}
</script>
<script>
// Right Click Disable
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

// Text Selection Disable
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
});

// Copy, Cut, Paste Disable
document.addEventListener('copy', function(e) {
    e.preventDefault();
});
document.addEventListener('cut', function(e) {
    e.preventDefault();
});
document.addEventListener('paste', function(e) {
    e.preventDefault();
});

// Keyboard Shortcuts Disable (Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I etc.)
document.addEventListener('keydown', function(e) {
    if (
        (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's' || e.key === 'a')) ||
        (e.ctrlKey && e.shiftKey && (e.key === 'i' || e.key === 'j')) ||
        (e.key === 'F12')
    ) {
        e.preventDefault();
    }
});
</script>


<?php include ('include/footer.php')?>
</body>
</html>


